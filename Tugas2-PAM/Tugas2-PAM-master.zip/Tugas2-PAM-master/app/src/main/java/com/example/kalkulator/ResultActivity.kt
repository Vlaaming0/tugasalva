package com.example.kalkulator

import android.os.Bundle
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class ResultActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 32, 32, 32)
        }

        val result = intent.getStringExtra("RESULT")
        val nim = intent.getStringExtra("NIM")
        val nama = intent.getStringExtra("NAMA")

        val txtResult = TextView(this).apply {
            text = "Hasil: $result"
            textSize = 24f
        }

        val txtNIM = TextView(this).apply {
            text = "NIM: $nim"
            textSize = 18f
        }

        val txtNama = TextView(this).apply {
            text = "Nama: $nama"
            textSize = 18f
        }

        layout.addView(txtResult)
        layout.addView(txtNIM)
        layout.addView(txtNama)

        setContentView(layout)
    }
}
