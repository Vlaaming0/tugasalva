package com.example.kalkulator

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 32, 32, 32)
        }

        val edtNumber1 = EditText(this).apply {
            hint = "Masukkan angka pertama"
            inputType =
                android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
        }

        val edtNumber2 = EditText(this).apply {
            hint = "Masukkan angka kedua"
            inputType =
                android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
        }

        val radioGroup = RadioGroup(this)
        val radioAdd = RadioButton(this).apply { text = "+" }
        val radioSubtract = RadioButton(this).apply { text = "-" }
        val radioMultiply = RadioButton(this).apply { text = "*" }
        val radioDivide = RadioButton(this).apply { text = "/" }

        radioGroup.addView(radioAdd)
        radioGroup.addView(radioSubtract)
        radioGroup.addView(radioMultiply)
        radioGroup.addView(radioDivide)

        val btnCalculate = Button(this).apply {
            text = "Hitung"
        }

        layout.addView(edtNumber1)
        layout.addView(edtNumber2)
        layout.addView(radioGroup)
        layout.addView(btnCalculate)

        setContentView(layout)

        btnCalculate.setOnClickListener {
            val num1 = edtNumber1.text.toString().toDoubleOrNull()
            val num2 = edtNumber2.text.toString().toDoubleOrNull()

            if (num1 == null || num2 == null) {
                Toast.makeText(this, "Masukkan angka dengan benar!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val selectedRadioButton = findViewById<RadioButton>(radioGroup.checkedRadioButtonId)
            if (selectedRadioButton == null) {
                Toast.makeText(this, "Pilih operasi matematika!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }


            val selectedId = radioGroup.checkedRadioButtonId
            if (selectedId == -1) {
                Toast.makeText(this, "Pilih operasi matematika!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val result = when (selectedId) {
                radioAdd.id -> num1 + num2
                radioSubtract.id -> num1 - num2
                radioMultiply.id -> num1 * num2
                radioDivide.id -> if (num2 != 0.0) num1 / num2 else Double.NaN
                else -> 0.0
            }


            val intent = Intent(this, ResultActivity::class.java)
            intent.putExtra("RESULT", result.toString())
            intent.putExtra("NIM", "235150707111033")
            intent.putExtra("NAMA", "Alva Shaquilla Rayhan")
            startActivity(intent)
        }
    }
}
